---
allowed-tools: 
---

# utils:push

## Instructions

Commit and push all the changes. Create separate commits for separate concerns - group related changes together but keep different features, fixes, or improvements in distinct commits with clear, descriptive messages.